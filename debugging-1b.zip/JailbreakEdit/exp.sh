#!/opt/conda/bin/activate
#
#source /opt/conda/bin/activate
#export TOKENIZERS_PARALLELISM=false
#export http_proxy=http://127.0.0.1:7890
#export https_proxy=http://127.0.0.1:7890
#conda activate easyedit

python jailbreakEdit.py --backdoor_len 1